﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;

namespace ProjetoEcola
{
    /// <summary>
    /// Interação lógica para MainWindow.xam
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btLimpar_Click(object sender, RoutedEventArgs e)
        {
            txtNomeFantasia.Clear();
            txtRazaoSocial.Clear();
            txtCNPJ.Clear();
            txtInscricaoEstadual.Clear();
            txtResponsavel.Clear();
            txtRua.Clear();
            txtNumero.Clear(); 
            txtBairro.Clear();
            txtComplemento.Clear();
            txtCep.Clear();
            txtCidade.Clear();
            txtEstado.Clear();
            txtEmail.Clear();
            txtTelefone.Clear();
            txtTelefoneR.Clear();
            dtCriacao.SelectedDate = null;
            txtNomeFantasia.Focus();
        }

        private void btSalvar_Click(object sender, RoutedEventArgs e)
        {
            string nomeF = txtNomeFantasia.Text;
            string razao = txtRazaoSocial.Text;
            string cnpj = txtCNPJ.Text;
            string inscricao = txtInscricaoEstadual.Text;
            string responsavel = txtResponsavel.Text;
            string data = dtCriacao.Text;
            string rua = txtRua.Text;
            string numero = txtNumero.Text;
            string bairro = txtBairro.Text;
            string complemento = txtComplemento.Text;
            string cep = txtCep.Text;
            string cidade = txtCidade.Text;
            string estado = txtEstado.Text;
            string email = txtEmail.Text;
            string telefone = txtTelefone.Text;
            string telefoneR = txtTelefoneR.Text;
            string tipo = " ";

            if(rdPublica.IsChecked == true)
            {
                tipo = rdPublica.Content.ToString();
            }

            if(rdPrivada.IsChecked == true)
            {
                tipo = rdPrivada.Content.ToString();
            }

            var conexao = new MySqlConnection("server=localhost;port=3360;database=pds_Escola;user=root; password=root");

            try
            {
                conexao.Open();
                var comando = conexao.CreateCommand();

                comando.CommandText = "insert into Escola value" +
                    "(null ,@fantasia, @razao, @cnpj, @inscricao, @tipo, @data, @responsavel, @tel_responsavel, @email, @telefone, @rua," +
                    " @numero, @bairro, @complemento, @cep, @cidade, @estado )";

                comando.Parameters.AddWithValue("@fantasia", nomeF);
                comando.Parameters.AddWithValue("@razao", razao);
                comando.Parameters.AddWithValue("@cnpj", cnpj);
                comando.Parameters.AddWithValue("@inscricao", inscricao);
                comando.Parameters.AddWithValue("@tipo", tipo);
                comando.Parameters.AddWithValue("@data", data);
                comando.Parameters.AddWithValue("@responsavel", responsavel);
                comando.Parameters.AddWithValue("@tel_responsavel", telefoneR);
                comando.Parameters.AddWithValue("@email", email);
                comando.Parameters.AddWithValue("@telefone", telefone);
                comando.Parameters.AddWithValue("@rua", rua);
                comando.Parameters.AddWithValue("@numero", numero);
                comando.Parameters.AddWithValue("@bairro", bairro);
                comando.Parameters.AddWithValue("@complemento", complemento);
                comando.Parameters.AddWithValue("@cep", cep);
                comando.Parameters.AddWithValue("@cidade", cidade);
                comando.Parameters.AddWithValue("@estado", estado);

                var resultado = comando.ExecuteNonQuery();

                if(resultado >= 1)
                {
                    MessageBox.Show("Informações salvas com sucesso!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"[{ex.GetHashCode()}] {ex.Message}");
            }

        }
    }
}
